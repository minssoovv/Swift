// 1.대입 연산자 (Assignment Operator)
    let b = 10
    var a = 5
    a = b       // b의 값을 초기화하거나 업데이트
    // a is now equal to 10

    let (x, y) = (1, 2)     // 튜플의 요소를 상수 또는 변수로 한번에 분해
    // x is equal to 1, and y is equal to 2


// 2.산술 연산자 (Arithmetic Operators)
    1 + 2       // equals 3
    5 - 3       // equals 2
    2 * 3       // equals 6
    10.0 / 2.5  // equals 4.0

    "hello, " + "world"  // equals "hello, world" // 덧셈 연산자는 문자열 연결도 지원


// 3.나머지 연산자 (Remainder Operator)
    -9 % 4   // equals -1 // -9 = (4 x -2) + -1


// 4.비교 연산자 (Comparison Operators)
    // 튜플은 2개의 값이 다를 때까지 왼쪽에서 오른쪽으로 한번에 하나씩 비교, 첫번째 요소가 같다면 계산 중지
    (1, "zebra") < (2, "apple")   // true because 1 is less than 2; "zebra" and "apple" are not compared
    (3, "apple") < (3, "bird")    // true because 3 is equal to 3, and "apple" is less than "bird"
    (4, "dog") == (4, "dog")      // true because 4 is equal to 4, and "dog" is equal to "dog"
    ("zebra" < "apple") // false
    ("b">"a") // true

    ("blue", -1) < ("purple", 1)        // OK, evaluates to true
    //("blue", false) < ("purple", true)  // Boolean값은 비교 불가


// 5.Nil-결합 연산자 (Nil-Coalescing Operator)
    // (a ?? b)는 옵셔널 a에 값이 있으면 a를 풀거나 a가 nil이면 기본값b를 반환합니다. 표현식 a는 항상 옵셔널 타입, 표현식 b는 a에 저장된 타입과 같아야 함
    let defaultColorName = "red"
    var userDefinedColorName: String?   // defaults to nil
    var colorNameToUse = userDefinedColorName ?? defaultColorName
    // userDefinedColorName is nil, so colorNameToUse is set to the default of "red"

    userDefinedColorName = "green"
    colorNameToUse = userDefinedColorName ?? defaultColorName
    // userDefinedColorName is not nil, so colorNameToUse is set to "green"


// 6.닫힌 범위 연산자 (Closed Range Operator)
    for index in 1...5 {    // 1 ~ 5
        print("\(index) times 5 is \(index * 5)")
    }
    // 1 times 5 is 5
    // 2 times 5 is 10
    // 3 times 5 is 15
    // 4 times 5 is 20
    // 5 times 5 is 25

// 7.반-열림 범위 연산자 (Half-Open Range Operator)
    // (a..<b)는 b가 포함되지 않은 a부터 b까지의 범위 실행
    let names = ["Anna", "Alex", "Brian", "Jack"]
    let count = names.count
    for i in 0..<count {
        print("Person \(i + 1) is called \(names[i])")
    }
    // Person 1 is called Anna
    // Person 2 is called Alex
    // Person 3 is called Brian
    // Person 4 is called Jack


// 8.단-방향 범위 (One-Sided Ranges)
    for name in names[2...] {   // 인덱스2부터 배열의 끝까지
        print(name)
    }
    // Brian
    // Jack

    for name in names[...2] {   // 배열의 처음부터 인덱스2까지
        print(name)
    }
    // Anna
    // Alex
    // Brian

    for name in names[..<2] {   // 단방향 형식도 가능
        print(name)
    }
    // Anna
    // Alex

    let range = ...5
    range.contains(7)   // false
    range.contains(4)   // true
    range.contains(-1)  // true


// 9.논리적 NOT 연산자 (logical NOT operator)
    //(!a)는 부울 값을 true를 false로 false를 true와 같이 반대로 만듦
    let allowedEntry = false
    if !allowedEntry {
        print("ACCESS DENIED")
    }
    // Prints "ACCESS DENIED"
