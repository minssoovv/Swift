// 변수와 상수
var myVariable = 42
myVariable = 50
let myConstant = 42


// 변수 뒤 :으로 타입 구분
let explicitDouble: Double = 70.0


// 값을 다른 타입으로 변경하려면 원하는 타입의 인스턴스를 생성
let lable = "The width is "
let width = 94
let widthLable = lable + String(width)


// ()안에 값을 작성하고 ()전에 \작성 == \()
let apples = 3
let oranges = 5
let appleSummary = " I have \(apples)"
let fruitSummary = "I have \(apples + oranges) pieces of fruit"


// 여러줄의 문자열을 사용할 때 """ ~~~~... """
let quotation = """
        Even though there's whitespace to the left,
        the actual lines aren't indented.
            Except for this line.
        Double Quotes (") can appear without being escaped.
        
        I still have \(apples + oranges) pieces of fruit.
        """


// [] 사용하여 배열과 딕셔너리를 생성
var fruits = ["strawberries", "limes", "tangerines"]
fruits[1] = "grapes"
print(fruits[1])

var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic",
]
occupations["Jayne"] = "Public Relations"
print(occupations["Jayne"]!) // 딕셔너리에 존재하지 않을 경우를 대비해서 옵셔널바인딩사용 or 강제 언래핑

fruits.append("blueberries") // 배열에 요소를 추가함에 따라 자동으로 크기 증가
print(fruits)


// 빈 배열 또는 딕셔너리를 사용할 떄 배열작성은 [] 딕셔너리는 [:]
fruits = []
occupations = [:]
let emptyArray: [String] = []
let emptyDictionary: [String: Float] = [:]


// if문의 조건문은 반드시 Boolean으로 표현(참 또는 거짓)
let individualScores = [75, 43, 103, 87, 12]
var teamScore = 0
for score in individualScores {
    if score > 50{
        teamScore += 3
    }
    else{
        teamScore += 1
    }
}
print(teamScore)


let scoreDecoration = if teamScore > 10{
    "O"
} else {
    "X"
}
print("Score:", teamScore, scoreDecoration)


// if와 let을 사용해 누락될 수 있는 값을 표현
var optionalString: String? = "Hello"
print(optionalString == nil) // prints "false"

var optionalName: String? = "John Appleseed"
var greeting = "Hello!"
if let name = optionalName {
    greeting = "Hello, \(name)"
}


// 옵셔널 값을 처리하는 다른 방법은 ?? 연산자를 사용
let nickName: String? = nil
let fullName: String = "John Appleseed"
let informalGreeting = "Hi \(nickName ?? fullName)" //nickName이 nil이면 fullName을 사용, 그렇지 않으면 nickName을 사용

if let nickName {
    print("Hey, \(nickName)") // nickName이 nil이기 떄문에 아무것도 출력할 수 없음
}
