// 1.상수와 변수 선언 (Declaring Constants and Variables)
    let maximumNumberOfLoginAttemps = 10 // 최대 로그인 시도 횟수는 변경되지 않아야 하므로 상수로 선언
    var currentLoginAttemp = 0 // 현재 로그인 시도 횟수는 실패 시 증가시켜야 하므로 변수로 선언

    var x = 0.0, y = 0.0, z = 0.0


// 1-1.타입 명시 (Type Annotations)
    var welcomeMessage: String // 선언할 변수의 타입 명시
    welcomeMessage = "Hello"

    var red, green, blue: Double // 여러개의 변수의 타입을 한줄로 선언


// 1-2.상수와 변수의 이름 (Naming constants and Variable)
    let n = 3.14159 // 상수와 변수 이름은 유니코드 문자를 포함하여 대부분의 문자를 포함
    let 你好 = "你好世界"
    let 🐶🐮 = "dogcow"


// 1-3.상수와 변수 출력 (Printing Constants and Variables)
    var friendlyWelcome = "Hello"
    print(friendlyWelcome) // Prints "Bonjour!" // print함수는 기본적으로 문자열을 출력한 후 \n 자동으로 추가
    let greeting = "Hello, Swift"
    print(greeting, terminator: "") // print함수의 매개변수 'terminator: ""' 사용하면 출력 후 \n을 추가하지 않음
    print("Swift Hello") // prints "Hello, SwiftSwift, Hello"


// 1-4.문자열 삽입 (String interpolation)
    let name = "minssoovv"
    print("Hello, My name is \(name).") // prints "Hello, My name is minssoovv."


// 2.주석 (Comments)

    // This is a comment.

    /* This is also a comment
     but is written over multiple lines. */

    /* This is the start of the first multiline comment.
    /* This is the second, nested multiline comment. */
       This is the end of the first multiline comment. */


// 3.세미콜론 (Semicolons)
    let cat = "🐱"; print(cat) // Prints "🐱" // 구문을 한줄로 작성할 경우 세미콜론을 작성해야 함


// 4.정수 (Integers)
    // 부호가 있는 정수: signed(양수, 0, 음수)
    // 부호가 없는 정수: unsigned(양수, 0)
    // 8, 16, 32, 64비트 형태의 signed, unsigned 지원 (32-bit unsigned: Int32)
    let minValue = UInt8.min  // minValue = 0
    let maxValue = UInt8.max  // maxValue = 255
    // 플랫폼의 네이티브 사이즈(화면크기나 해상도)가 필요한 경우에만 unsigned 사용(저장될 값이 음수가 아니여도 Int를 선호)


// 5.부동 소수점 숫자 (Floating-Point Number)
    // Float은 6자리의 소수점 정확도를 가지고 있는 것에 반해 Double은 최소 15자리의 소수점 정확도를 가지고 있어 Double이 더 선호됨


// 6.타입 세이프티와 타입 추론 (Type Safety and Type Inference)
    // Swift는 코드를 컴파일할 때 타입 검사를 수행하고 일치하지 않는 타입을 오류로 표시(다른타입으로 작성할 때 오류를 피하는데 도움이 됨)
    // Swift는 코드를 컴파일할 떄 타입을 자동으로 추론
    let meaningOfLife = 42 // 타입을 선언하지 않아도 Int로 추론


// 7.숫자 리터럴 (Numeric Literals)
    // 접두사 없는 10진수
    // 0b 접두사로 2진수
    // 0o 접두사로 8진수
    // 0x 접두사로 16진수

    let decimalInteger = 17
    let binaryInteger = 0b10001       // 17의 2진수
    let octalInteger = 0o21           // 17의 8진수
    let hexadecimalInteger = 0x11     // 17의 16진수
    
    // 1.25e2 = 1.25 x 10^2
    // 1.25e-2 = 1.25 x 10^-2
    // 0xFp2 = 15 x 2^2
    //0xF-2 = 15 x 2^-2

    let paddedDouble = 000123.456 // 읽기 쉽게 만드는 추가 포맷 포함 가능
    let oneMillion = 1_000_000
    let justOverOneMillion = 1_000_000.000_000_1


// 7-1.정수 변환 (Integer Conversion)
    let twoThousand: UInt16 = 2_000
    let one: UInt8 = 1
    let twoThousandAndOne = twoThousand + UInt16(one) // one의 값을 새로운 UInt16으로 초기화(양쪽의 타입이 UInt이므로 덧셈 가능)


// 7-2.정수와 붑동 소수점 변환 (Integer and Floating-Point Conversion)
    let three = 3
    let pointOneFourOneFiveNine = 0.14159
    let pi = Double(three) + pointOneFourOneFiveNine // 양쪽의 타입을 동일하게 바꿔야함, pi = 3.14159
    let integerPi = Int(pi) // Double형 pi를 Int형으로 변환, pi = 3


// 8.타입 별칭 (Type Aliases)
    var audioSample = Int8.min // audioSample = -128
    typealias AudioSample = UInt16 // 이미 존재하는 타입을 typealias를 이용해 다른 이름으로 정의
    var maxAmplitudeFound = AudioSample.min // maxAmplitudeFound = 0


// 9.부울 (Boolean)
    // Boolean은 상수 값인 true 또는 false만 제공
    let orangesAreOrange = true
    let turnipsAreDelicious = false

    if turnipsAreDelicious {
        print("Mmm, tasty turnips!")
    } else {
        print("Eww, turnips are horrible.")
    }
        // Prints "Eww, turnips are horrible."


// 10.튜플 (Tuples)
    // 데이터구조가 간단한 경우 사용
    let http404Error = (404, "Not Found") // 튜플의 타입은 (Int, String)

    let (statusCode, statusMessage) = http404Error // 튜플의 내용을 상수 또는 변수로 분해 가능
    print("The status code is \(statusCode)")
    // Prints "The status code is 404"
    print("The status message is \(statusMessage)")
    // Prints "The status message is Not Found"

    let (justTheStatusCode, _) = http404Error // 튜플의 값 중 일부만 필요한 경우 _(밑줄)로 튜플 일부를 무시 가능
    print("The status code is \(justTheStatusCode)")
    // Prints "The status code is 404"

    let http200Status = (statusCode: 200, description: "OK") // 튜플 요소에 이름 지정
    print("The status code is \(http200Status.statusCode)") // 튜플 요소에 이름이 있다면 요소의 값에 요소 이름으로 접근 가능
    // Prints "The status code is 200"
    print("The status message is \(http200Status.description)")
    // Prints "The status message is OK"


// 11.옵셔널 (Optionals)
    // 지정된 타입에 값이 없는 경우 사용
    let possibleNumber = "123" // "123"이 아니라 "Hello Swift"인 경우 nil
    let convertedNumber = Int(possibleNumber) // String을 Int로 초기화 // 일부 문자열만 정수로 변환(문자열 "Hello Swift"는 변환할 숫자값이 없음)


// 11-1.nil
    // 옵셔널 변수에 특수한 값 nil로 지정하여 값이 없는 상태를 나타낼 수 있음
    var serverResponseCode: Int? = 404 // 옵셔널 타입을 작성하려면 옵셔널을 포함하는 타입의 이름 다음에 ?을 작성
    // serverResponseCode contains an actual Int value of 404
    serverResponseCode = nil // 옵셔널타입(?)으로 nil 설정 가능
    // serverResponseCode now contains no value

    var surveyAnswer: String? // 기본값이 없으면 자동으로 nil로 설정
    // surveyAnswer is automatically set to nil

    if convertedNumber != nil {     // 연산자를 이용해 옵셔널에 값이 포함되어 있는지 확인할 수 있음
        print("convertedNumber contains some integer value.")
    }
    // Prints "convertedNumber contains some integer value."


// 11-2.옵셔널 바인딩 (Optional Binding)
    // 옵셔널이 값을 포함하고 있는지 확인하고 값이 있는 경우 해당 값을 상수 또는 변수로 사용할 수 있게 함
    // 주로 if let, guard let 구문에서 사용
    if let actualNumber = Int(possibleNumber) {
        print("The string \"\(possibleNumber)\" has an integer value of \(actualNumber)") // "123"일 경우
    } else {
        print("The string \"\(possibleNumber)\" could not be converted to an integer") // "Hello Swift"일 경우
    }
    // Prints "The string "123" has an integer value of 123"


    let myNumber = Int(possibleNumber)
    // Here, myNumber is an optional integer
    if let myNumber = myNumber {        // myNumber에 값이 있는지 없는지 확인, 있다면 myNumber라는 상수에 설정
        // Here, myNumber is a non-optional integer
        print("My number is \(myNumber)")
    }
    // Prints "My number is 123"


    if let firstNumber = Int("4"), let secondNumber = Int("42"), firstNumber < secondNumber && secondNumber < 100 {
        print("\(firstNumber) < \(secondNumber) < 100")     // if구문에 쉼표로 구분하여 옵셔널 바인딩 및 부울 조건 여러개를 포함할 수 있음
    }
    // Prints "4 < 42 < 100"

    if let firstNumber = Int("4") {     // (줄이지 않은 경우)     // if구문에서 옵셔널 바인딩으로 생성된 상수나 변수는 if구문 내에서만 사용 가능(firstNum..)
        if let secondNumber = Int("42") {
            if firstNumber < secondNumber && secondNumber < 100 {
                print("\(firstNumber) < \(secondNumber) < 100")
            }
        }
    }
    // Prints "4 < 42 < 100"


// 11-3.대체값 제공 (Providing a Fallback Value)
    let name_: String? = nil
    let greeting_ = "Hello, " + (name_ ?? "friend") + "!"   // 옵셔널에서 ??의 왼쪽이 nil이 아니면 값은 언래핑되고 사용, nil이 아니면 오른쪽 값 사용
    print(greeting_) // Prints "Hello, friend!"


// 11-4.강제 언래핑 (Force Unwrapping)
    // 프로그래머의 에러 또는 원치않는 상태와 같은 실패를 nil로 표현하려면 옵셔널의 이름 뒤에 느낌표(!)를 추가
    let possibleNumber_ = "123"
    let convertedNumber_ = Int(possibleNumber_)

    let number = convertedNumber_!  // 강제 언래핑

    guard let number = convertedNumber_ else {      // 옵셔널 값이 존재하지 않는 경우 프로그램 종료
        fatalError("The number was invalid")
    }


// 11-5.암시적으로 언래핑된 옵셔널 (Implicitly Unwrapped Optionals)
    let possibleString: String? = "An optional string."     //
    let forcedString: String = possibleString! // Requires explicit unwrapping

    let assumedString: String! = "An implicitly unwrapped optional string."   // 항상 값이 있다고 가정 (nil이 될 가능성이 있다면 사용하면 안됨)
    let implicitString: String = assumedString // Unwrapped automatically

    if assumedString != nil {
        print(assumedString!)
    }
    // Prints "An implicitly unwrapped optional string."

    if let definiteString = assumedString {
        print(definiteString)
    }
    // Prints "An implicitly unwrapped optional string."


// 12.에러 처리 (Error Handling)
    // 값의 존재 유무를 사용하여 함수의 true or false를 전달하는 옵셔널과 달리 에러 처리는 원인을 판별하고 필요한 경우 에러를 프로그램의 다른 부분으로 전파 가능
    
    func canThrowAnError() throws {     // 함수 선언에 throws 키워드를 포함시켜 에러가 발생할 수 있음을 나타냄
        // this function may or may not throw an error
    }

    // do구문은 에러를 하나 이상으로 catch절로 전파할 수 있는 새로운 범위를 만듦
    do {
        try canThrowAnError()       // 에러를 발생할 수 있는 함수를 호출할 때는 표현식 앞에 try 키워드를 사용
        // no error was thrown
    } catch {                       // catch절에 의해 처리될 때까지 현재 범위에서 에러를 자동으로 전파
        // an error was thrown
    }


/* 2024/02/07 */
